"""Use sealed HairGS foreground Gaussian depth in the frozen B0 RGB transfer.

This is a geometry-proposal diagnostic, not proof of a front strand surface.
Only train evidence qualifies changes; no target reference mask enters rendering.
"""
import sys,json,argparse,time
from pathlib import Path
import numpy as np,cv2,torch
O=Path(__file__).resolve().parent;R=O.parent;sys.path.insert(0,str(R/'code/LookCloser/scripts'))
from study_dec5_hair_geometry import Scene,Renderer,display
from run_dec5_hair_campaign import sha
p=argparse.ArgumentParser();p.add_argument('--prediction',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--core-prediction',type=Path);a=p.parse_args()
seal=json.loads((a.prediction/'predictions_sealed.json').read_text())
core_seal=json.loads((a.core_prediction/'predictions_sealed.json').read_text()) if a.core_prediction else None
a.output.mkdir(exist_ok=False)
s=Scene(R,load_rgb=True,mvs=R/'pm1920_native_v2',mesh=R/'center_tsdf_base/mesh.ply');renderer=Renderer(s);records=[]
for cam in s.validation:
    name=cam['physical_camera'];rec=next(x for x in seal['records'] if x['camera']==name)
    assert sha(a.prediction/(name+'.npz'))==rec['npz_sha256']
    candidate=np.load(a.prediction/(name+'.npz'));parent=np.load(R/'c_complete_base'/(name+'.npz'))
    depth=candidate['foreground_camera_z_expected'];alpha=candidate['foreground_opacity']
    if a.core_prediction:
        cr=next(r for r in core_seal['records'] if r['camera']==name)
        assert sha(a.core_prediction/(name+'.npz'))==cr['npz_sha256']
        core=np.load(a.core_prediction/(name+'.npz'))
        depth=core['camera_z_strand_core'];alpha=core['projected_core_coverage'].astype(np.float32)
    domain=parent['roi']&(parent['skin_probability']<.7)&(depth>0)&(alpha>.5)
    proposed=parent['front_depth'].copy();proposed[domain]=depth[domain]
    result=renderer.warp(cam,torch.tensor(proposed,device='cuda'))
    values={k:v.cpu().numpy() for k,v in result.items()}
    gate=domain&(values['support']>=3)&(values['hair_probability']>=.5)&(values['skin_probability']<.7)
    # Baseline-exact outside the evidence-qualified target hair domain.
    arrays={k:parent[k].copy() for k in parent.files}
    for k in ['rgb','source_id','support','hair_probability','skin_probability','reprojection_error']:
        arrays[k][gate]=values[k][gate]
    arrays['front_depth'][gate]=proposed[gate]
    if 'neural_fallback' in arrays:arrays['neural_fallback'][gate]=False
    arrays['hairgs_depth_domain']=domain;arrays['hairgs_depth_gate']=gate
    if a.core_prediction:
        arrays['hairgs_strand_core_z']=depth;arrays['hairgs_core_coverage']=alpha.astype(bool)
    else:
        arrays['hairgs_foreground_expected_z']=depth;arrays['hairgs_foreground_opacity']=alpha
    assert np.array_equal(arrays['rgb'][~gate],parent['rgb'][~gate])
    np.savez_compressed(a.output/(name+'.npz'),**arrays)
    cv2.imwrite(str(a.output/(name+'.png')),np.rint(display(arrays['rgb'])[...,::-1]*255).astype(np.uint8))
    records.append(dict(camera=name,png_sha256=sha(a.output/(name+'.png')),npz_sha256=sha(a.output/(name+'.npz')),
        proposed_pixels=int(domain.sum()),changed_pixels=int(gate.sum()),
        qualified_original_roundtrip_mean=float(values['reprojection_error'][gate].mean()) if gate.any() else None,
        baseline_same_pixel_roundtrip_mean=float(parent['reprojection_error'][gate].mean()) if gate.any() else None))
(a.output/'complete.json').write_text(json.dumps(dict(method=('HairGS nearest projected polyline-core z, not tube-front or alpha' if a.core_prediction else 'HairGS foreground Gaussian conditional expected-z')+', >=3 original measured witnesses',
    records=records,baseline_sha256=sha(R/'c_complete_base/complete.json'),hairgs_prediction_seal_sha256=sha(a.prediction/'predictions_sealed.json'),
    uses_validation_rgb=False,uses_test_rgb=False,uses_original_measured_depth_for_visibility=True,units='calibration camera-z',
    core_prediction_seal_sha256=sha(a.core_prediction/'predictions_sealed.json') if a.core_prediction else None,
    outside_qualified_domain_exact_baseline=True,geometry_is_strand_front_surface=False,train_sources=[f['physical_camera'] for f in s.frames]),indent=2))
print(json.dumps(records),flush=True)
