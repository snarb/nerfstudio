"""Freeze three native HairGS predictions before accessing validation RGB."""
import sys,json,time,hashlib,argparse
from pathlib import Path
import numpy as np,cv2,torch
from plyfile import PlyData
O=Path(__file__).resolve().parent; R=O.parent
sys.path.insert(0,str(O/'upstream'));sys.path.insert(0,str(R/'code/LookCloser/scripts'))
from scene import GaussianModel,HairGaussianModel
from scene.cameras import Camera
from gaussian_renderer import render
from dec5_hair import cv_pose,VALIDATION,project
from run_dec5_hair_campaign import sha
p=argparse.ArgumentParser();p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
torch.set_num_threads(4);torch.cuda.set_per_process_memory_fraction(24*(1<<30)/torch.cuda.get_device_properties(0).total_memory)
a.output.mkdir(exist_ok=False)
ply=PlyData.read(a.checkpoint);cls=GaussianModel if len(ply.elements)==1 else HairGaussianModel
model=cls(0,device='cuda');model.load_ply(str(a.checkpoint))
if isinstance(model,HairGaussianModel):
    model.ref_strand_root=np.load(O/'head_reconstruction_data.npz')['scalp_verts']
class ForegroundProxy:
    def __init__(self,model):self.model=model
    def __getattr__(self,key):return getattr(self.model,key)
    @property
    def get_opacity(self):return self.model.get_opacity*self.model.compute_foreground_mask()[:,None]
fgmodel=ForegroundProxy(model)
payload=json.loads((R/'dataset/transforms.json').read_text());rows=[]
for frame in payload['frames']:
    name=frame['physical_camera']
    if name not in VALIDATION:continue
    pose=cv_pose(frame);w2c=np.linalg.inv(pose);w,h=frame['w'],frame['h']
    cam=Camera(0,w2c[:3,:3].T,w2c[:3,3],2*np.arctan(w/(2*frame['fl_x'])),2*np.arctan(h/(2*frame['fl_y'])),torch.zeros((3,h,w)),None,name,0,
        cx_offset=2*(frame['cx']/w-.5),cy_offset=2*(frame['cy']/h-.5))
    # Audit the calibrated head volume, not ill-conditioned off-screen model outliers.
    xyz=np.load(O/'head_reconstruction_data.npz')['head_verts'][::250];reference,zz=project(xyz,frame)
    homogeneous=np.c_[xyz,np.ones(len(xyz))]@cam.full_proj_transform.detach().cpu().numpy()
    actual=(homogeneous[:,:2]/homogeneous[:,3:4]+1)*np.array([w,h])/2-.5
    projection_error=float(np.linalg.norm(actual[zz>.1]-(reference[zz>.1]-.5),axis=-1).max())
    assert projection_error<.1,('Calibration projection mismatch',name,projection_error)
    bg=torch.zeros(3,device='cuda');N=len(model.get_xyz)
    with torch.inference_mode():
        pred=render(cam,model,bg)['render'].clamp(0,1).permute(1,2,0).cpu().numpy()
        assert np.isfinite(pred).all(),('Nonfinite rendered RGB',name)
        opacity=render(cam,model,bg,override_color=torch.ones((N,3),device='cuda'))['render'][0]
        pc=(model.get_xyz-torch.tensor(pose[:3,3],device='cuda',dtype=torch.float32))@torch.tensor(pose[:3,:3],device='cuda',dtype=torch.float32)
        z=pc[:,2:3].expand(-1,3).contiguous()
        zsum=render(cam,model,bg,override_color=z)['render'][0]
        depth=torch.where(opacity>.1,zsum/opacity.clamp_min(1e-8),0).cpu().numpy()
        hair=render(cam,model,bg,override_color=model.get_mask.expand(-1,3).contiguous())['render'][0].cpu().numpy()
        fga=render(cam,fgmodel,bg,override_color=torch.ones((N,3),device='cuda'))['render'][0]
        fgz=render(cam,fgmodel,bg,override_color=z)['render'][0]
        foreground_depth=torch.where(fga>.1,fgz/fga.clamp_min(1e-8),0).cpu().numpy()
        foreground_opacity=fga.cpu().numpy()
        opacity=opacity.cpu().numpy()
    cv2.imwrite(str(a.output/(name+'.png')),np.rint(pred[...,::-1]*255).astype(np.uint8))
    np.savez_compressed(a.output/(name+'.npz'),camera_z_expected=depth,opacity=opacity,hair_coverage=hair,foreground_camera_z_expected=foreground_depth,foreground_opacity=foreground_opacity)
    rows.append(dict(camera=name,png_sha256=sha(a.output/(name+'.png')),npz_sha256=sha(a.output/(name+'.npz')),projection_numeric_max_error_px=projection_error))
(a.output/'predictions_sealed.json').write_text(json.dumps(dict(checkpoint=str(a.checkpoint),checkpoint_sha256=sha(a.checkpoint),records=rows,
    train_cameras=59,validation_rgb_loaded=False,test_rgb_loaded=False,renderer='native upstream HairGS, own fitted RGB; not hard-source GT transfer',depth='opacity-conditional expected Gaussian camera-z; not certified front or strand geometry',units='calibration units, metric scale unverified'),indent=2))
print(json.dumps(dict(checkpoint=str(a.checkpoint),output=str(a.output),records=len(rows),peak_gpu_mib=torch.cuda.max_memory_allocated()/2**20)),flush=True)
