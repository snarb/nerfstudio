"""Native HairGS RGB metrics; keep renderer difference explicit."""
import sys,json,argparse
from pathlib import Path
import numpy as np,cv2,torch
O=Path(__file__).resolve().parent;R=O.parent
sys.path.insert(0,str(R/'code/LookCloser/scripts'))
from score_dec5_hair import metrics
from torchmetrics.image.lpip import LearnedPerceptualImagePatchSimilarity
from run_dec5_hair_campaign import sha
p=argparse.ArgumentParser();p.add_argument('--prediction',type=Path,required=True);a=p.parse_args()
seal=json.loads((a.prediction/'predictions_sealed.json').read_text());payload=json.loads((R/'dataset/transforms.json').read_text())
torch.set_num_threads(2);lpips=LearnedPerceptualImagePatchSimilarity(net_type='alex',normalize=True).eval();rows=[]
for rec in seal['records']:
    n=rec['camera'];f=next(f for f in payload['frames'] if f['physical_camera']==n)
    assert f['file_path'] in payload['val_filenames']
    assert sha(a.prediction/(n+'.png'))==rec['png_sha256']
    pred=cv2.imread(str(a.prediction/(n+'.png')))[...,::-1].astype(np.float32)/255
    gt=cv2.imread(str(R/'dataset'/f['file_path']))[...,::-1].astype(np.float32)/255
    sem=np.load(R/'validation_reference'/(n+'.npz'))['probability'].astype(np.float32)/65535
    hair=sem[...,0]>.5;face=sem[...,1]>.5
    masks=dict(full_frame=np.ones(hair.shape,bool),hair=hair,face_neck=face)
    arrays=np.load(a.prediction/(n+'.npz'));hpred=arrays['hair_coverage']>.5
    tp=(hair&hpred).sum();fp=(~hair&hpred).sum();fn=(hair&~hpred).sum()
    row=dict(camera=n,**{k:metrics(pred,gt,m,lpips) for k,m in masks.items()},hair_silhouette=dict(precision=float(tp/max(tp+fp,1)),recall=float(tp/max(tp+fn,1)),f1=float(2*tp/max(2*tp+fp+fn,1))),hair_opacity_holes_fraction=float(((arrays['opacity']<.1)&hair).sum()/max(hair.sum(),1)))
    rows.append(row)
    yy,xx=np.nonzero(hair|face);x0,x1=max(0,xx.min()-16),min(pred.shape[1],xx.max()+17);y0,y1=max(0,yy.min()-16),min(pred.shape[0],yy.max()+17)
    b0=cv2.imread(str(R/'c_complete_base'/(n+'.png')))
    panes=[gt,pred]
    if b0 is not None:panes.insert(1,b0[...,::-1].astype(np.float32)/255)
    panel=np.concatenate([np.rot90(x[y0:y1,x0:x1]) for x in panes],1)
    panel=cv2.resize(panel,None,fx=min(1,1400/panel.shape[1]),fy=min(1,1400/panel.shape[1]))
    cv2.imwrite(str(a.prediction/(n+'_review.jpg')),np.rint(panel[...,::-1]*255).astype(np.uint8))
agg={r:{k:float(np.mean([v[r][k] for v in rows])) for k in ['psnr','ssim','lpips']} for r in ['full_frame','hair','face_neck']}
result=dict(aggregate=agg,per_view=rows,eval_all_psnr=agg['full_frame']['psnr'],protocol='native HairGS RGB; B0 hard-source RGB renderer differs; numerical comparison is diagnostic, not isolated geometry ablation',seal_sha256=sha(a.prediction/'predictions_sealed.json'),test_rgb_loaded=False)
(a.prediction/'metrics.json').write_text(json.dumps(result,indent=2));print(json.dumps(result['aggregate']),flush=True)
