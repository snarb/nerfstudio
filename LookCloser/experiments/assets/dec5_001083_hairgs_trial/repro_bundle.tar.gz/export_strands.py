"""Export exact HairGS connectivity and honest root/length diagnostics."""
import sys,argparse,json
from pathlib import Path
import numpy as np,torch
from scipy.spatial import cKDTree
from plyfile import PlyData,PlyElement
O=Path(__file__).resolve().parent;sys.path.insert(0,str(O/'upstream'))
sys.path.insert(0,str(O.parent/'code/LookCloser/scripts'))
from scene import HairGaussianModel
from run_dec5_hair_campaign import sha
p=argparse.ArgumentParser();p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
a.output.mkdir(exist_ok=False);torch.set_num_threads(4)
g=HairGaussianModel(0,device='cuda');g.load_ply(str(a.checkpoint));g.ref_strand_root=np.load(O/'head_reconstruction_data.npz')['scalp_verts'];g.compute_strands_info()
points=g._endpoints.detach().cpu().numpy();edges=g.endpoint_pairs.cpu().numpy();fg=g.compute_foreground_mask().cpu().numpy();edges_fg=edges[fg]
strands=g.strands_info.list_strands
lengths=[];counts=[];roots=[]
offsets=[0];flatten=[]
for strand in strands:
    ids=np.r_[strand[:,0],strand[-1,1]]
    flatten.extend(ids.tolist());offsets.append(len(flatten));counts.append(len(ids));roots.append(points[ids[0]])
    lengths.append(float(np.linalg.norm(np.diff(points[ids],axis=0),axis=-1).sum()))
rootdist=cKDTree(g.ref_strand_root).query(np.asarray(roots))[0]
used=np.unique(edges_fg);compact_points=points[used];compact_edges=np.searchsorted(used,edges_fg)
compact_ids=np.searchsorted(used,np.array(flatten))
np.savez_compressed(a.output/'strands.npz',points=compact_points,edges=compact_edges,strand_point_ids=compact_ids,strand_offsets=np.array(offsets),root_distance_to_approx_scalp=rootdist,segment_opacity=g.get_opacity.detach().cpu().numpy()[fg],segment_mask_probability=g.get_mask.detach().cpu().numpy()[fg],segment_scaling=g.get_scaling.detach().cpu().numpy()[fg])
points=compact_points;edges_fg=compact_edges
vertices=np.empty(len(points),dtype=[('x','f4'),('y','f4'),('z','f4')]);vertices[:]=list(map(tuple,points))
e=np.empty(len(edges_fg),dtype=[('vertex1','i4'),('vertex2','i4')]);e[:]=list(map(tuple,edges_fg))
PlyData([PlyElement.describe(vertices,'vertex'),PlyElement.describe(e,'edge')]).write(a.output/'strands_edges.ply')
q=lambda v:np.quantile(v,[0,.05,.5,.95,1]).tolist()
report=dict(checkpoint=str(a.checkpoint),checkpoint_sha256=sha(a.checkpoint),strand_archive_sha256=sha(a.output/'strands.npz'),
    gaussian_segments=len(edges),foreground_segments=len(edges_fg),foreground_strands=len(strands),strand_points_quantiles=q(counts),length_quantiles=q(lengths),root_distance_to_approx_scalp_quantiles=q(rootdist),fraction_roots_within_001=float((rootdist<=.01).mean()),
    units='calibration units; not certified metric',scalp='anatomical ellipsoid approximation',root_contact_enforced=False,gt_strand_accuracy_available=False)
(a.output/'geometry.json').write_text(json.dumps(report,indent=2));print(json.dumps(report),flush=True)
