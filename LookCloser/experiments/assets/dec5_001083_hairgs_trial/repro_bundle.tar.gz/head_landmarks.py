import sys,json
from pathlib import Path
import numpy as np, cv2
R=Path('/mnt/footage2/lookcloser_hair_001083_20261027_1330'); O=R/'hairgs_trial_20261027_171606'
sys.path.insert(0,str(R/'code/LookCloser/scripts'))
from study_dec5_hair_geometry import Scene
from dec5_hair import unproject,project
s=Scene(R,load_rgb=False,mvs=R/'pm1920_native_v2')
labels={
'A004_B005_1210RN':{'nose':[396,360],'chin':[388,321],'forehead':[565,340],'ear':[501,258]},
'C004_D005_12107I':{'nose':[418,235],'chin':[352,202],'forehead':[539,192],'ear':[494,75]},
'F004_A005_12103K':{'nose':[432,373],'chin':[381,338],'forehead':[561,393],'ear':[507,260]},
'H004_B005_1210EL':{'nose':[453,310],'chin':[386,284],'forehead':[561,330],'ear':[524,198]},
'J004_C005_1210I4':{'nose':[449,276],'chin':[378,241],'forehead':[560,280],'ear':[500,165]},
'L004_E005_1210RM':{'nose':[458,258],'chin':[386,233],'forehead':[550,302],'ear':[478,181],'other_ear':[400,328]}}
observations={}
for cam,dep in zip(s.cameras,s.depth):
    name=cam['physical_camera']
    if name not in labels: continue
    for key,p in labels[name].items():
        uv=np.array(p)*2
        x,y=np.floor(uv).astype(int)
        patch=dep[max(y-4,0):y+5,max(x-4,0):x+5]; good=patch[patch>0]
        if len(good)==0:continue
        point=unproject(uv[None],np.array([np.median(good)]),cam)[0]
        observations.setdefault(key,[]).append(dict(camera=name,uv=uv.tolist(),point=point.tolist(),depth_spread=float(np.std(good))))
averages={k:np.median([v['point'] for v in records],0) for k,records in observations.items()}
out={'labels_half_resolution':labels,'observations':observations,'averages':{k:v.tolist() for k,v in averages.items()}}
for k,recs in observations.items():
    for rec in recs:
        cam=next(c for c in s.cameras if c['physical_camera']==rec['camera'])
        uv,z=project(averages[k][None],cam)
        rec['mean_landmark_reprojection_error_px']=float(np.linalg.norm(uv[0]-rec['uv']))
(O/'head_landmarks.json').write_text(json.dumps(out,indent=2)); print(json.dumps(out),flush=True)
