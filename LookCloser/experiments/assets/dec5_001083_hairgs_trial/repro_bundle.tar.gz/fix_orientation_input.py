from pathlib import Path
import numpy as np,cv2,json
O=Path('/mnt/footage2/lookcloser_hair_001083_20261027_1330/hairgs_trial_20261027_171606')
I=O/'input'; base=O.parent/'native_hairgs_input/orientations'
if (I/'orientations').is_symlink():(I/'orientations').unlink()
(I/'orientations').mkdir(exist_ok=True)
for p in base.glob('*'):
    dst=I/'orientations'/p.name
    if p.name.endswith('_orientation.png'):
        angle=cv2.imread(str(p),0).astype(np.float32)*np.pi/255
        # Existing adapter is atan2(dy,dx), HairGS is atan2(dx,dy).
        angle=np.mod(np.pi/2-angle,np.pi)
        cv2.imwrite(str(dst),np.rint(angle*255/np.pi).astype(np.uint8))
    elif not dst.exists():dst.symlink_to(p)
(O/'orientation_adapter.json').write_text(json.dumps(dict(old='angle from +x toward +y, modulo pi',new='HairGS atan2(dx,dy): angle from +y toward +x, modulo pi',formula='new=(pi/2-old)%pi',unit_vectors_check={'horizontal':{'old':0,'new':np.pi/2},'vertical':{'old':np.pi/2,'new':0}},quantization='uint8 theta*255/pi; inherited originals untouched'),indent=2))
