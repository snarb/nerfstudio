"""Native-HD zero-width polyline-core z-buffer; coverage is NOT alpha."""
import sys,os,json,argparse,hashlib
os.environ.setdefault('OPENCV_IO_ENABLE_OPENEXR','1')
from pathlib import Path
import numpy as np,cv2
from numba import njit
O=Path(__file__).resolve().parent;R=O.parent;sys.path.insert(0,str(R/'code/LookCloser/scripts'))
from dec5_hair import cv_pose,VALIDATION
from run_dec5_hair_campaign import sha
@njit(cache=True)
def raster(xyz,edges,fx,fy,cx,cy,w,h):
    depth=np.full((h,w),np.inf,np.float32);count=np.zeros((h,w),np.int32)
    for i in range(len(edges)):
        a,b=edges[i];z0,z1=xyz[a,2],xyz[b,2]
        if z0<=.01 or z1<=.01:continue
        u0,v0=fx*xyz[a,0]/z0+cx,fy*xyz[a,1]/z0+cy
        u1,v1=fx*xyz[b,0]/z1+cx,fy*xyz[b,1]/z1+cy
        du,dv=u1-u0,v1-v0;tlo,thi=0.,1.;ok=True
        for p,d,lo,hi in [(u0,du,0.,float(w)),(v0,dv,0.,float(h))]:
            if abs(d)<1e-12:
                if p<lo or p>=hi:ok=False
            else:
                t0,t1=(lo-p)/d,(hi-p)/d
                if t0>t1:t0,t1=t1,t0
                tlo=max(tlo,t0);thi=min(thi,t1)
        if not ok or thi<tlo:continue
        steps=max(1,int(np.ceil(max(abs(du),abs(dv))*(thi-tlo)*2)))
        lastx,lasty=-1,-1
        for j in range(steps+1):
            t=tlo+(thi-tlo)*j/steps;x,y=int(np.floor(u0+du*t)),int(np.floor(v0+dv*t))
            if x<0 or x>=w or y<0 or y>=h or (x==lastx and y==lasty):continue
            z=1/((1-t)/z0+t/z1)
            if z<depth[y,x]:depth[y,x]=z
            count[y,x]+=1;lastx,lasty=x,y
    for y in range(h):
        for x in range(w):
            if not np.isfinite(depth[y,x]):depth[y,x]=0
    return depth,count
p=argparse.ArgumentParser();p.add_argument('--geometry',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(exist_ok=False)
g=np.load(a.geometry/'strands.npz');points=g['points'];edges=g['edges']
payload=json.loads((R/'dataset/transforms.json').read_text());rows=[]
for f in payload['frames']:
    name=f['physical_camera']
    if name not in VALIDATION:continue
    pose=cv_pose(f);xyz=(points-pose[:3,3])@pose[:3,:3]
    depth,count=raster(xyz,edges,f['fl_x'],f['fl_y'],f['cx'],f['cy'],f['w'],f['h'])
    np.savez_compressed(a.output/(name+'.npz'),camera_z_strand_core=depth,projected_core_coverage=count>0,segments_per_pixel=count)
    cv2.imwrite(str(a.output/(name+'_camera_z.exr')),depth)
    rows.append(dict(camera=name,npz_sha256=sha(a.output/(name+'.npz')),exr_sha256=sha(a.output/(name+'_camera_z.exr')),covered_pixels=int((count>0).sum())))
(a.output/'predictions_sealed.json').write_text(json.dumps(dict(geometry_sha256=sha(a.geometry/'strands.npz'),records=rows,uses_validation_rgb=False,uses_test_rgb=False,
    definition='Nearest projected zero-width polyline core, rasterized to native pixels at half-pixel lattice; perspective-correct camera-z; not tube-front surface, not alpha, not Gaussian expected-z',units='calibration camera-z; metric scale unverified'),indent=2))
for row in rows:
    name=row['camera'];f=next(f for f in payload['frames'] if f['physical_camera']==name)
    d=np.load(a.output/(name+'.npz'));hit=d['projected_core_coverage'];z=d['camera_z_strand_core']
    sem=np.load(R/'validation_reference'/(name+'.npz'))['probability'].astype(np.float32)/65535;hair=sem[...,0]>.5
    row['core_pixels_in_reference_hair_fraction']=float((hit&hair).sum()/max(hit.sum(),1));row['reference_hair_pixels_hit_by_core_fraction']=float((hit&hair).sum()/max(hair.sum(),1))
    yy,xx=np.nonzero((sem[...,0]>.5)|(sem[...,1]>.5));x0,x1=max(0,xx.min()-16),min(hit.shape[1],xx.max()+17);y0,y1=max(0,yy.min()-16),min(hit.shape[0],yy.max()+17)
    base=cv2.imread(str(R/'c_complete_base'/(name+'.png')));over=base.copy();over[hit]=(0,255,0)
    vals=z[y0:y1,x0:x1];known=vals>0;lo,hi=np.quantile(vals[known],[.02,.98]) if known.any() else (0,1)
    normalized=np.where(z>0,np.clip((z-lo)/max(hi-lo,1e-6),0,1),0);colored=cv2.applyColorMap(np.rint(normalized*255).astype(np.uint8),cv2.COLORMAP_TURBO);colored[~hit]=0
    panel=np.concatenate([np.rot90(v[y0:y1,x0:x1]) for v in [base,over,colored]],1);factor=min(1,1400/panel.shape[1]);panel=cv2.resize(panel,None,fx=factor,fy=factor)
    cv2.imwrite(str(a.output/(name+'_review.jpg')),panel)
(a.output/'coverage_diagnostics.json').write_text(json.dumps(dict(records=rows,coverage_is_alpha=False,semantic_reference_is_fallible=True,definition='Geometric core raster only: do not interpret sparse-core coverage as opaque hair silhouette'),indent=2));print(json.dumps(rows),flush=True)
