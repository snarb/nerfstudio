"""Train-only anatomical ellipsoid proxy; never fit the exterior hair surface."""
import sys,json,hashlib
from pathlib import Path
import numpy as np,cv2
from scipy.spatial import cKDTree
R=Path('/mnt/footage2/lookcloser_hair_001083_20261027_1330');O=R/'hairgs_trial_20261027_171606'
sys.path.insert(0,str(R/'code/LookCloser/scripts'))
from study_dec5_hair_geometry import Scene
from dec5_hair import project
l=json.loads((O/'head_landmarks.json').read_text()); x={k:np.array(v) for k,v in l['averages'].items()}
up=x['forehead']-x['chin'];up/=np.linalg.norm(up)
earmid=(x['ear']+x['other_ear'])/2
front=x['nose']-earmid;front-=up*np.dot(front,up);front/=np.linalg.norm(front)
right=np.cross(up,front);right/=np.linalg.norm(right)
B=np.stack([right,up,front],1);center=earmid+up*.045
radii=np.array([np.linalg.norm(x['ear']-x['other_ear'])/2,.185,.170])
az=np.linspace(0,2*np.pi,160,endpoint=False); lat=np.linspace(-np.pi/2+.01,np.pi/2-.01,100)
aa,ll=np.meshgrid(az,lat)
unit=np.stack([np.cos(ll)*np.sin(aa),np.sin(ll),np.cos(ll)*np.cos(aa)],-1).reshape(-1,3)
head=(unit*radii)@B.T+center
# Hairline prior: upper/rear cranium, with forehead excluded. Ear-band lower cap
# is intentionally approximate and is not inferred from the hair envelope.
keep=(unit[:,1]>-.10)&((unit[:,2]<.60)|(unit[:,1]>.55))
scalp=head[keep].astype(np.float32)
np.savez_compressed(O/'head_reconstruction_data.npz',head_verts=head.astype(np.float32),scalp_verts=scalp)
report=dict(type='anatomical_ellipsoid_approximation_NOT_FLAME_NOT_certified_scalp',train_only=True,
    uses_test_rgb=False,uses_validation_rgb=False,hair_surface_used_for_fitting=False,
    center=center.tolist(),basis_right_up_front=B.tolist(),radii_calibration_units=radii.tolist(),
    head_vertices=len(head),scalp_vertices=len(scalp),
    constraints='Ear-span width; chin-to-forehead up; nose-to-earmid forward; center ear-mid+0.045 up; up radius .185 and front radius .170 are anatomical priors, not metric-certified.',
    limitations='Manual broad nonhomologous surface cues; hidden cranium/scalp unconstrained; no exact hairline, root directions, head skin detail or strand GT.',
    landmark_source_sha256=hashlib.sha256((O/'head_landmarks.json').read_bytes()).hexdigest())
s=Scene(R,load_rgb=False,mvs=R/'pm1920_native_v2'); rows=[]
for i,(cam,dep,sem) in enumerate(zip(s.cameras,s.depth,s.semantic)):
    uv,z=project(scalp,cam); xy=np.floor(uv).astype(int)
    valid=(z>0)&(xy[:,0]>=0)&(xy[:,0]<cam['w'])&(xy[:,1]>=0)&(xy[:,1]<cam['h'])
    v=np.flatnonzero(valid);xx,yy=xy[v].T
    hair=sem[yy,xx,0]>.5; skin=sem[yy,xx,1]>.5; measured=dep[yy,xx]
    good=hair&(measured>0)
    margin=z[v][good]-measured[good]
    rows.append(dict(camera=cam['physical_camera'],projected=len(v),hair_fraction=float(hair.mean()),
        person_fraction=float((hair|skin).mean()),measured_hair_pairs=int(good.sum()),
        scalp_in_front_of_observed_hair_gt02_fraction=float((margin<-.02).mean()) if len(margin) else None,
        scalp_behind_hair_margin_quantiles=np.quantile(margin,[.05,.5,.95]).tolist() if len(margin) else None))
    if cam['physical_camera'] in l['labels_half_resolution']:
        image=cv2.imread(str(s.data/cam['file_path']))
        # Draw a sparse scalp cloud plus only a sparse wire grid for full head.
        huv,hz=project(head,cam)
        for j in range(0,len(head),10):
            a,b=np.floor(huv[j]).astype(int)
            if hz[j]>0 and 0<=a<image.shape[1] and 0<=b<image.shape[0]: cv2.circle(image,(a,b),1,(0,180,255),-1)
        for j in range(0,len(scalp),8):
            a,b=xy[j]
            if valid[j]:cv2.circle(image,(a,b),2,(0,255,0),-1)
        for key,p in l['labels_half_resolution'][cam['physical_camera']].items():
            cv2.drawMarker(image,tuple(np.array(p)*2),(255,0,255),cv2.MARKER_CROSS,14,2)
        cv2.imwrite(str(O/(cam['physical_camera']+'_head_overlay.jpg')),cv2.resize(image,(960,540)))
report['projections_train59']=rows
obs=np.load(O/'head_observations.npz');h=obs['hair']
dist=cKDTree(h).query(scalp)[0];report['scalp_to_measured_hair_nn_quantiles']=np.quantile(dist,[.05,.5,.95]).tolist()
face=(obs['face']-center)@B;sel=(face[:,1]>-.12)&(face[:,2]>.07)
res=np.sqrt(((face[sel]/radii)**2).sum(-1))-1
report['upper_frontal_skin_ellipsoid_normalized_residual_quantiles']=np.quantile(res,[.05,.5,.95]).tolist()
(O/'approx_head_fit.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='projections_train59'}),flush=True)
