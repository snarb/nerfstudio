import sys, json
from pathlib import Path
import numpy as np
import cv2
R=Path('/mnt/footage2/lookcloser_hair_001083_20261027_1330')
O=R/'hairgs_trial_20261027_171606'
sys.path.insert(0,str(R/'code/LookCloser/scripts'))
from study_dec5_hair_geometry import Scene
from dec5_hair import unproject, project
s=Scene(R,load_rgb=False,mvs=R/'pm1920_native_v2')
bounds=np.asarray(json.loads((R/'center_tsdf_base/mesh.json').read_text())['bounds'])
data={k:[] for k in ['face','hair']}
for i,(cam,dep,sem) in enumerate(zip(s.cameras,s.depth,s.semantic)):
    for k,c in [('hair',0),('face',1)]:
        yy,xx=np.nonzero((sem[...,c]>.9)&(dep>0))
        yy,xx=yy[::16],xx[::16]
        xyz=unproject(np.stack([xx+.5,yy+.5],-1),dep[yy,xx],cam)
        ok=((xyz>bounds[0])&(xyz<bounds[1])).all(-1)
        data[k].append(xyz[ok])
    if i%10==0: print(i,flush=True)
data={k:np.concatenate(v) for k,v in data.items()}
np.savez_compressed(O/'head_observations.npz',**data)
report={k:dict(n=len(x),quantiles=np.quantile(x,[.01,.1,.25,.5,.75,.9,.99],axis=0).tolist(),mean=x.mean(0).tolist()) for k,x in data.items()}
(O/'head_observations.json').write_text(json.dumps(report,indent=2))
for i in [0,10,20,30,40,50]:
    f=s.frames[i]; im=cv2.imread(str(s.data/f['file_path']))
    cv2.imwrite(str(O/(f['physical_camera']+'_train.jpg')),cv2.resize(im,(960,540)))
print(json.dumps(report),flush=True)
