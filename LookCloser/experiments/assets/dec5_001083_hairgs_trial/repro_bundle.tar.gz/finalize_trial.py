import os,json,time,hashlib,datetime,subprocess
from pathlib import Path
import numpy as np,cv2
O=Path(__file__).resolve().parent;R=O.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
baseline=read(R/'c_metrics_base.json');native=read(O/'best_native_hairgs_candidate.json');receiver=read(O/'best_hairgs_candidate.json')
audits=[]
for label in ['default_final','corrected_final','selected_native']:
    D=O/('geometry_'+label);g=np.load(D/'strands.npz');p,e,ids,off=[g[k] for k in ['points','edges','strand_point_ids','strand_offsets']]
    assert np.isfinite(p).all() and e.min()>=0 and e.max()<len(p) and ids.min()>=0 and ids.max()<len(p)
    assert off[0]==0 and off[-1]==len(ids) and (np.diff(off)>=2).all() and int((np.diff(off)-1).sum())==len(e)
    degree=np.bincount(e.reshape(-1),minlength=len(p));assert degree.max()<=2 and len(p)-len(e)==len(off)-1
    assert sha(D/'strands.npz')==read(D/'geometry.json')['strand_archive_sha256']
    audit=dict(label=label,finite_coordinates=True,indices_valid=True,component_offsets_valid=True,max_vertex_degree=int(degree.max()),vertices=len(p),edges=len(e),components=len(off)-1,forest_euler_consistent=True)
    (D/'export_audit.json').write_text(json.dumps(audit,indent=2));audits.append(audit)
    C=O/('cores_'+label);rows=[]
    for x in read(C/'predictions_sealed.json')['records']:
        n=x['camera'];a=np.load(C/(n+'.npz'));z=a['camera_z_strand_core'];decoded=cv2.imread(str(C/(n+'_camera_z.exr')),cv2.IMREAD_UNCHANGED)
        assert decoded.dtype==np.float32 and decoded.shape==(1080,1920) and np.array_equal(decoded,z) and np.isfinite(decoded).all() and (decoded>=0).all()
        assert np.array_equal(decoded>0,a['projected_core_coverage']) and sha(C/(n+'.npz'))==x['npz_sha256'] and sha(C/(n+'_camera_z.exr'))==x['exr_sha256']
        rows.append(dict(camera=n,exact_exr_roundtrip=True,valid_pixels=int((decoded>0).sum())))
    (C/'depth_delivery_audit.json').write_text(json.dumps(dict(records=rows,resolution=[1920,1080],dtype='float32',units='OpenCV camera-z, original calibration units; metric scale unverified',unknown_value=0,unknown_is_empty_space=False,coverage_is_alpha=False,head_occlusion_applied=False,not_normalized_ray_distance=True),indent=2))
receipts=[read(p) for p in O.glob('*_receipt.json') if 'worker_pid' in read(p)]
gpu_receipts=[r for r in receipts if r['label']!='smoke']
peak_own_mib=0;minimum_free_mib=1e12
for r in receipts:
    for line in Path(r['supervision']).read_text().splitlines():
        c=json.loads(line)
        try:
            fields=c['gpu'].split(',');minimum_free_mib=min(minimum_free_mib,float(fields[1].split()[0])-float(fields[0].split()[0]))
        except (ValueError,IndexError):pass
        for item in c['gpu_processes'].splitlines():
            fields=[x.strip() for x in item.split(',')]
            if len(fields)>=3 and fields[0]==str(r['worker_pid']):
                try:peak_own_mib=max(peak_own_mib,float(fields[-1].split()[0]))
                except ValueError:pass
progress=[]
for folder in ['model_smoke','model_main','model_corrected']:
    p=O/folder/'progress.jsonl'
    if p.exists():progress.extend(json.loads(x) for x in p.read_text().splitlines())
cuda_seconds=0;training=[]
for label in ['smoke2','stage1','stage3_default','stage3_default_retry32','stage1_corrected','stage3_corrected']:
    r=next(r for r in receipts if r['label']==label)
    begin=datetime.datetime.fromisoformat(r['start_utc']).timestamp();end=datetime.datetime.fromisoformat(r['end_utc']).timestamp()
    pp=[x for x in progress if begin<=x['unix']<=end]
    total=max((x.get('total_cuda_event_ms',0) for x in pp),default=0)/1000;cuda_seconds+=total
    training.append(dict(label=label,wall_seconds=r['wall_seconds'],cuda_forward_backward_event_seconds=total,returncode=r['returncode'],peak_torch_mib=max((x.get('peak_allocated_mib',0) for x in pp),default=0)))
alive=[]
for r in receipts:
    path=Path('/proc')/str(r['worker_pid'])/'cmdline'
    if path.exists() and str(O).encode() in path.read_bytes():alive.append(r['worker_pid'])
assert not alive
protected=subprocess.check_output(['ps','-p','3718826','-o','pid=,etime=,args='],text=True).strip();assert 'calibration_service' in protected
now=datetime.datetime.now(datetime.timezone.utc);start=datetime.datetime.fromisoformat('2026-10-27T17:16:06+00:00')
resources=dict(start_utc=start.isoformat(),finished_utc=now.isoformat(),deadline_utc='2026-10-27T21:16:06Z',wall_seconds=(now-start).total_seconds(),gpu_stage_process_wall_seconds=sum(r['wall_seconds'] for r in gpu_receipts),gpu_stage_wall_definition='Controller process wall for GPU stages, includes their CPU/IO; firstsmoke2/stage1 controllers add <=30s polling slack each',cuda_forward_backward_event_seconds=cuda_seconds,peak_torch_mib=max(x.get('peak_allocated_mib',0) for x in progress),peak_own_gpu_process_mib_sampled=peak_own_mib,minimum_global_free_gpu_mib_sampled=minimum_free_mib,training=training,protected_process=protected,own_workers_alive=alive,oom='One own24GiB-capOOM;32GiB retry completed; device still had64.98GiBfree duringcapOOM',gpu_stage_count=len(gpu_receipts))
(O/'resource_accounting.json').write_text(json.dumps(resources,indent=2))
selection=dict(accepted='B0 unchanged',hairgs_adopted=False,native_checkpoint_selection=native,receiver_checkpoint_selection=receiver,evaluated_strand_checkpoints=22,test_rgb_opened=False,path96_run=False,path96_reason='Material validationRGB/geometry gate failed',core_diagnostics=['metrics_transfer_core_default_final.json','metrics_transfer_core_selected_native.json'],selected_native_geometry='geometry_selected_native',selected_native_depth_delivery='cores_selected_native',source_dataset_sha256=sha(R/'dataset/transforms.json'),baseline_metrics_sha256=sha(R/'c_metrics_base.json'))
(O/'final_selection.json').write_text(json.dumps(selection,indent=2))
summary=dict(selection=selection,resources=resources,baseline=baseline,default_final=read(O/'metrics_transfer_default_final.json'),corrected_final=read(O/'metrics_transfer_corrected_final.json'),selected_native_expected=read(O/('metrics_transfer_'+native['label']+'.json')),core_default=read(O/'metrics_transfer_core_default_final.json'),core_selected=read(O/'metrics_transfer_core_selected_native.json'),geometry={label:read(O/('geometry_'+label)/'geometry.json') for label in ['default_final','corrected_final','selected_native']},head_proxy=read(O/'approx_head_fit.json'))
(O/'trial_summary.json').write_text(json.dumps(summary,indent=2))
(O/'patches.diff').write_text(subprocess.check_output(['git','diff'],cwd=O/'upstream',text=True))
(O/'STATE.json').write_text(json.dumps(dict(status='complete',summary=str(O/'trial_summary.json'),finished_utc=now.isoformat(),own_gpu_workers_alive=[],test_rgb_opened=False,accepted='B0 unchanged'),indent=2))
print(json.dumps(dict(wall_hours=resources['wall_seconds']/3600,gpu_stage_hours=resources['gpu_stage_process_wall_seconds']/3600,cuda_event_hours=cuda_seconds/3600,peak_torch_gib=resources['peak_torch_mib']/1024,minimum_free_gpu_gib=minimum_free_mib/1024,protected=protected,accepted=selection['accepted'])),flush=True)
