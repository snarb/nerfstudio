"""CPU-only native-RGB checkpoint selection, separate from B0 receiver scores."""
import os,sys,json,time,subprocess,datetime,hashlib
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parent;PY=sys.executable
env=os.environ.copy();env['PYTHONPATH']=str(O/'deps')+':'+str(R/'model_deps');env['OMP_NUM_THREADS']='2'
deadline=datetime.datetime.fromisoformat('2026-10-27T21:16:06+00:00').timestamp();scored={}
while time.time()<deadline and not (O/'stop_native_score').exists():
    try:rows=json.loads((O/'checkpoint_selection_progress.json').read_text())
    except (FileNotFoundError,json.JSONDecodeError):time.sleep(2);continue
    for row in rows:
        if 'aggregate' not in row or row['label'] in scored:continue
        prediction=Path(row['native']);metric=prediction/'metrics.json'
        if not metric.exists():
            with (O/('score_native_'+row['label']+'.log')).open('wb') as log:
                subprocess.run([PY,str(O/'score_validation.py'),'--prediction',str(prediction)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=max(1,deadline-time.time()))
        m=json.loads(metric.read_text());seal=json.loads((prediction/'predictions_sealed.json').read_text())
        assert seal['checkpoint_sha256']==row['checkpoint_sha256']
        scored[row['label']]=dict(label=row['label'],config=row['config'],iteration=row['iteration'],strand_optimization_steps=row['strand_optimization_steps'],checkpoint=row['checkpoint'],checkpoint_sha256=row['checkpoint_sha256'],native=str(prediction),metrics=str(metric),aggregate=m['aggregate'])
        (O/'native_checkpoint_selection_progress.json').write_text(json.dumps(list(scored.values()),indent=2))
        print(json.dumps(dict(label=row['label'],native_psnr=m['eval_all_psnr'],native_lpips=m['aggregate']['full_frame']['lpips'])),flush=True)
    if (O/'checkpoint_selection_complete.json').exists() and len(scored)==len(rows):break
    time.sleep(2)
else:raise RuntimeError('Native checkpoint selection interrupted/deadline')
best_psnr=max(x['aggregate']['full_frame']['psnr'] for x in scored.values())
pool=[x for x in scored.values() if x['aggregate']['full_frame']['psnr']>=best_psnr-.07]
best=min(pool,key=lambda x:(x['aggregate']['full_frame']['lpips'],-x['aggregate']['full_frame']['psnr']))
best['selection_space']='native upstream HairGS RGB';best['maximum_eval_all_psnr']=best_psnr;best['tie_band_db']=.07;best['evaluated_checkpoint_count']=len(scored);best['test_rgb_opened']=False
(O/'best_native_hairgs_candidate.json').write_text(json.dumps(best,indent=2));print('SELECTED_NATIVE '+best['label'],flush=True)
