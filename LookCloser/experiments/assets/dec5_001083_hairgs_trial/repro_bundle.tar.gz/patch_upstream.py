from pathlib import Path
import json,shutil,subprocess
O=Path('/mnt/footage2/lookcloser_hair_001083_20261027_1330/hairgs_trial_20261027_171606');U=O/'upstream'
p=U/'data/dataset_readers.py';t=p.read_text().replace('astype(np.bool)','astype(bool)')
t=t.replace('    height: int\n','    height: int\n    cx: float\n    cy: float\n')
t=t.replace('            height=height,','            height=height,\n            cx=float(intr.params[-2]),\n            cy=float(intr.params[-1]),')
p.write_text(t)
p=U/'scene/cameras.py';t=p.read_text().replace('        orientation_confidence=None,','        orientation_confidence=None,\n        cx_offset=0.0,\n        cy_offset=0.0,')
t=t.replace('        self.full_proj_transform = (','        self.projection_matrix[2, 0] = cx_offset\n        self.projection_matrix[2, 1] = cy_offset\n        self.full_proj_transform = (')
t=t.replace('        mask=mask,','        mask=mask,\n        cx_offset=2*(cam_info.cx/cam_info.width-.5),\n        cy_offset=2*(cam_info.cy/cam_info.height-.5),')
p.write_text(t)
p=U/'train.py';t=p.read_text().replace('                and iteration % gp.eval_frequency == 0\n                or iteration == opt.iterations','                and (iteration % gp.eval_frequency == 0\n                or iteration == opt.iterations)')
t=t.replace('    network_gui.init(gp.ip, gp.port)','    torch.cuda.set_per_process_memory_fraction(24*(1<<30)/torch.cuda.get_device_properties(0).total_memory)\n    network_gui.init(args.ip, args.port)')
# Exact progress+resource records, with no dependence on TTY progress bars.
t=t.replace('            # Save scene\n','            if iteration % 100 == 0:\n                import json, time, os\n                with open(os.path.join(scene.model_path,"progress.jsonl"),"a") as f:\n                    f.write(json.dumps(dict(step=training_info.iter,unix=time.time(),gaussians=len(gaussians.get_xyz),allocated_mib=torch.cuda.memory_allocated()/2**20,peak_allocated_mib=torch.cuda.max_memory_allocated()/2**20,iteration_gpu_ms=training_info.elapsed_time))+"\\n")\n\n            # Save scene\n')
p.write_text(t)
# argparse ParamGroups store defaults; merge used these directly and ignored CLI.
p=U/'merge.py';t=p.read_text().replace('    args = parser.parse_args()','    args = parser.parse_args()\n    op = op.extract(args)\n    gp = gp.extract(args)\n    torch.cuda.set_per_process_memory_fraction(24*(1<<30)/torch.cuda.get_device_properties(0).total_memory)');p.write_text(t)
I=O/'input';I.mkdir(exist_ok=True)
base=O.parent/'native_hairgs_input'
for k in ['images','masks','orientations']:
    if not (I/k).exists():(I/k).symlink_to(base/k,target_is_directory=True)
shutil.copytree(base/'sparse',I/'sparse',dirs_exist_ok=True)
shutil.copy2(O/'head_reconstruction_data.npz',I/'head_reconstruction_data.npz')
(O/'patches.diff').write_text(subprocess.check_output(['git','diff'],cwd=U,text=True))
(O/'trial_manifest.json').write_text(json.dumps(dict(start_utc='2026-10-27T17:16:06Z',deadline_utc='2026-10-27T21:16:06Z',upstream_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=U,text=True).strip(),input_split='train59; no validation/test fitting',scalp='approximate anatomical ellipsoid; no FLAME assets found',env='base gs2 python reused read-only, all extra dependencies private deps target; CUDA12.6 compute90 PTX for Blackwell',test_rgb_accessed=False),indent=2))
