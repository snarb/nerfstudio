import sys,argparse,subprocess,json,os
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parent;PY=sys.executable
p=argparse.ArgumentParser();p.add_argument('--name',required=True);p.add_argument('--checkpoint',type=Path,required=True);p.add_argument('--selection-only',action='store_true');a=p.parse_args()
env=os.environ.copy();env['PYTHONPATH']=str(O/'deps')+':'+str(R/'model_deps');env['OMP_NUM_THREADS']='2'
log=(O/('evaluate_'+a.name+'.log')).open('wb')
native=O/('native_'+a.name);geometry=O/('geometry_'+a.name);transfer=O/('transfer_'+a.name)
jobs=[('render',[PY,str(O/'render_validation.py'),'--checkpoint',str(a.checkpoint),'--output',str(native)]),
      ('geometry',[PY,str(O/'export_strands.py'),'--checkpoint',str(a.checkpoint),'--output',str(geometry)]),
      ('transfer',[PY,str(O/'transfer_hairgs_depth.py'),'--prediction',str(native),'--output',str(transfer)])]
if a.selection_only:jobs=[x for x in jobs if x[0]!='geometry']
for suffix,cmd in jobs:
    subprocess.run([PY,str(O/'controlled_run.py'),a.name+'_'+suffix]+cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
(O/(a.name+'_gpu_evaluation_complete.json')).write_text(json.dumps(dict(checkpoint=str(a.checkpoint),native=str(native),geometry=None if a.selection_only else str(geometry),transfer=str(transfer))))
if not a.selection_only:subprocess.run([PY,str(O/'score_validation.py'),'--prediction',str(native)],cwd=O,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run([PY,str(R/'code/LookCloser/scripts/score_dec5_hair.py'),'--root',str(R),'--prediction',str(transfer),'--output',str(O/('metrics_transfer_'+a.name+'.json'))],cwd=O,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print(json.dumps(dict(name=a.name,checkpoint=str(a.checkpoint),status='evaluated')),flush=True)
