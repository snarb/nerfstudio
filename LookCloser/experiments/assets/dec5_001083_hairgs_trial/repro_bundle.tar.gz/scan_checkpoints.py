"""Select among every saved strand checkpoint; never fit or open test RGB."""
import os,sys,json,time,subprocess,hashlib,datetime
from pathlib import Path
O=Path(__file__).resolve().parent;PY=sys.executable
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
deadline=datetime.datetime.fromisoformat('2026-10-27T21:16:06+00:00').timestamp()
candidates=[]
for config,folder,merge_step,final in [('default','model_main',30008,35008),('corrected','model_corrected',30007,35007)]:
    for p in sorted((O/folder/'point_cloud').glob('iteration_*/point_cloud.ply'),key=lambda p:int(p.parent.name.split('_')[-1])):
        iteration=int(p.parent.name.split('_')[-1])
        if iteration<merge_step:continue
        delta=iteration-merge_step
        label=config+'_final' if iteration==final else config+'_s%05d'%delta
        candidates.append(dict(config=config,iteration=iteration,strand_optimization_steps=delta,label=label,checkpoint=str(p),checkpoint_sha256=sha(p)))
(O/'selection_protocol_all_saved.json').write_text(json.dumps(dict(reason='Honor best-checkpoint selection across all saved strand states, including500-step safety saves added for capOOM recovery; no new training configs',partition='validation3',test_rgb_opened=False,metric='mean full-frame PSNR across3validation; among candidates within.07dB of maximum, minimum mean full-frame LPIPS',original_protocol_sha256=sha(O/'selection_protocol.json'),candidate_count=len(candidates)),indent=2))
for row in candidates:
    label=row['label'];metric=O/('metrics_transfer_'+label+'.json')
    if not metric.exists():
        if time.time()>deadline-120:raise RuntimeError('Insufficient deadline budget for another checkpoint')
        with (O/('scan_'+label+'.log')).open('wb') as log:
            subprocess.run([PY,str(O/'evaluate_checkpoint.py'),'--name',label,'--checkpoint',row['checkpoint'],'--selection-only'],stdout=log,stderr=subprocess.STDOUT,check=True)
    m=json.loads(metric.read_text());assert m['partition']=='validation' and len(m['per_view'])==3
    seal=json.loads((O/('native_'+label)/'predictions_sealed.json').read_text());assert seal['checkpoint_sha256']==row['checkpoint_sha256']
    row.update(metrics=str(metric),metrics_sha256=sha(metric),aggregate=m['aggregate'],native=str(O/('native_'+label)),transfer=str(O/('transfer_'+label)))
    (O/'checkpoint_selection_progress.json').write_text(json.dumps(candidates,indent=2))
    print(json.dumps(dict(label=label,psnr=m['aggregate']['full_frame']['psnr'],lpips=m['aggregate']['full_frame']['lpips'],hair_lpips=m['aggregate']['hair']['lpips'])),flush=True)
best_psnr=max(x['aggregate']['full_frame']['psnr'] for x in candidates)
eligible=[x for x in candidates if x['aggregate']['full_frame']['psnr']>=best_psnr-.07]
best=min(eligible,key=lambda x:(x['aggregate']['full_frame']['lpips'],-x['aggregate']['full_frame']['psnr']))
(O/'checkpoint_selection_complete.json').write_text(json.dumps(dict(candidates=candidates,maximum_eval_all_psnr=best_psnr,tie_band_db=.07,selected=best,test_rgb_opened=False,selected_predictions_already_sealed=True),indent=2))
(O/'best_hairgs_candidate.json').write_text(json.dumps(best,indent=2));print('SELECTED '+best['label'],flush=True)
