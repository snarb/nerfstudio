"""CPU audit of initializer RGB, SH roundtrip, coordinate and exposure ranges."""
import sys,json
from pathlib import Path
import numpy as np,cv2
from plyfile import PlyData
O=Path(__file__).resolve().parent;R=O.parent;sys.path.insert(0,str(R/'code/LookCloser/scripts'))
from study_dec5_hair_geometry import Scene
from dec5_hair import unproject
pc= PlyData.read(O/'input/sparse/0/points3D.ply')['vertex']
points=np.stack([pc[k] for k in ['x','y','z']],1)
rgb=np.stack([pc[k] for k in ['red','green','blue']],1).astype(np.float64)/255
C0=.28209479177387814;sh=(rgb-.5)/C0;back=sh*C0+.5
s=Scene(R,load_rgb=False,mvs=R/'pm1920_native_v2');cam=s.cameras[0];frame=s.frames[0];dep=s.depth[0];sem=s.semantic[0]
yy,xx=np.nonzero((dep>0)&(sem[...,0]>.8));yy,xx=yy[::32],xx[::32]
recomputed=unproject(np.stack([xx+.5,yy+.5],-1),dep[yy,xx],cam)
im=cv2.imread(str(s.data/frame['file_path']))[...,::-1]
col=im[yy,xx].astype(np.float64)/255
assert len(recomputed)>0
match_xyz=float(np.abs(recomputed-points[:len(recomputed)]).max())
match_rgb=float(np.abs(col-rgb[:len(col)]).max())
assert match_xyz<1e-6 and match_rgb==0
bounds=np.asarray(json.loads((R/'center_tsdf_base/mesh.json').read_text())['bounds'])
q=lambda x:np.quantile(x,[0,.01,.5,.99,1],axis=0).tolist()
r=dict(initial_points=len(points),initial_rgb_range_quantiles=q(rgb),initial_SH_dc_range_quantiles=q(sh),rgb_sh_roundtrip_max_error=float(np.abs(rgb-back).max()),
    initializer_first_train_camera=frame['physical_camera'],first_camera_recomputed_points=len(recomputed),first_camera_xyz_max_error=match_xyz,first_camera_rgb_max_error=match_rgb,
    initializer_outside_broad_head_bounds_fraction=float((~((points>=bounds[0])&(points<=bounds[1])).all(-1)).mean()),
    initializer_xyz_quantiles=q(points),exposure='Initializer colours and training RGB are identical uint8 display PNG pixels; RGB2SH consumes colours/255; no extra exposure factor',
    scalp_used_for_stage1_geometry=False)
for name,path in [('trained_stage1',O/'model_main/point_cloud/iteration_30000/point_cloud.ply')]:
    g=PlyData.read(path)['vertex'];co=np.stack([g['f_dc_'+str(i)] for i in range(3)],1)*C0+.5
    pos=np.stack([g[k] for k in ['x','y','z']],1);scale=np.exp(np.stack([g['scale_'+str(i)] for i in range(3)],1))
    opacity=1/(1+np.exp(-np.clip(g['opacity'],-80,80)))
    r[name]=dict(n=len(g),unclamped_SH_rgb_quantiles=q(co),rgb_any_channel_above1_fraction=float((co>1).any(-1).mean()),rgb_any_channel_below0_fraction=float((co<0).any(-1).mean()),
        sigma_scaling_quantiles=q(scale),opacity_quantiles=q(opacity),xyz_quantiles=q(pos),high_color_opacity_quantiles=q(opacity[(co>1).any(-1)]),
        nonfinite_count=int((~np.isfinite(co)).sum()+(~np.isfinite(pos)).sum()))
(O/'rgb_initialization_audit.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
