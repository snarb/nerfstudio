"""Repair hair-only initializer/full-frame objective mismatch, using train MVS."""
import sys,json,shutil
from pathlib import Path
import numpy as np,cv2
from plyfile import PlyData,PlyElement
O=Path(__file__).resolve().parent;R=O.parent;sys.path.insert(0,str(R/'code/LookCloser/scripts'))
from study_dec5_hair_geometry import Scene
from dec5_hair import unproject
s=Scene(R,load_rgb=False,mvs=R/'pm1920_native_v2');I=O/'input_corrected';I.mkdir(exist_ok=False)
for k in ['images','masks','orientations']:(I/k).symlink_to((O/'input'/k).resolve(),target_is_directory=True)
shutil.copytree(O/'input/sparse',I/'sparse');shutil.copy2(O/'head_reconstruction_data.npz',I/'head_reconstruction_data.npz')
pc=PlyData.read(O/'input/sparse/0/points3D.ply')['vertex'];xyz=np.stack([pc[k] for k in ['x','y','z']],1);rgb=np.stack([pc[k] for k in ['red','green','blue']],1)
b=np.asarray(json.loads((R/'center_tsdf_base/mesh.json').read_text())['bounds']);keep=((xyz>=b[0])&(xyz<=b[1])).all(-1)
points=[xyz[keep]];colors=[rgb[keep]];extra=[];ec=[];rows=[]
for frame,cam,dep,photo,sem in zip(s.frames,s.cameras,s.depth,s.photo,s.semantic):
    valid=(dep>0)&(photo>0)&(np.abs(dep-photo)<=.01*dep+.002)&(sem[...,0]<.1)
    yy,xx=np.nonzero(valid);yy,xx=yy[::128],xx[::128]
    q=unproject(np.stack([xx+.5,yy+.5],-1),dep[yy,xx],cam)
    good=np.isfinite(q).all(-1)
    image=cv2.imread(str(s.data/frame['file_path']))[...,::-1]
    extra.append(q[good]);ec.append(image[yy[good],xx[good]])
    rows.append(dict(camera=frame['physical_camera'],nonhair_measured_points=int(good.sum())))
extra=np.concatenate(extra);ec=np.concatenate(ec)
stride=max(1,int(np.ceil(len(extra)/250000)));points.append(extra[::stride]);colors.append(ec[::stride])
xyz=np.concatenate(points).astype(np.float32);rgb=np.concatenate(colors).astype(np.uint8)
dtype=[('x','f4'),('y','f4'),('z','f4'),('nx','f4'),('ny','f4'),('nz','f4'),('red','u1'),('green','u1'),('blue','u1')]
v=np.empty(len(xyz),dtype=dtype);v[:]=list(map(tuple,np.c_[xyz,np.zeros_like(xyz),rgb]))
PlyData([PlyElement.describe(v,'vertex')]).write(I/'sparse/0/points3D.ply')
with (I/'sparse/0/points3D.txt').open('w') as f:
    f.write('# Train-only measured MVS, no SfM tracks. Hair bounds cleaned; nonhair initializer added.\n')
    for i,(p,c) in enumerate(zip(xyz,rgb),1):f.write('%d %.9g %.9g %.9g %d %d %d 0\n'%((i,)+tuple(p)+tuple(c)))
r=dict(train_cameras=59,uses_validation_rgb=False,uses_test_rgb=False,changes=['Remove hair-initializer points outside previously train-derived broad head bounds','Add measured nonhair MVS points to match full-frame RGB objective','Use lambda_orientation=1 instead of100 for approximate structure-tensor orientations'],
    clean_hair_points=int(keep.sum()),removed_hair_outliers=int((~keep).sum()),added_nonhair_points=len(xyz)-int(keep.sum()),total_points=len(xyz),nonhair_qualification='Original geometric and photometric depths agree within1%+.002 calibration units; source hair semantic probability<.1; deterministic native-raster stride128, at most250k points',
    pure_lambda_ablation=False,all_rgb_images_and_cameras_unchanged=True,original_input_unchanged=True,per_camera=rows)
(O/'corrected_input.json').write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items() if k!='per_camera'}),flush=True)
