"""Run one owned process group with 30s durable resource/progress checks."""
import sys,os,time,json,subprocess,signal,datetime
from pathlib import Path
O=Path(__file__).resolve().parent
deadline=datetime.datetime.fromisoformat('2026-10-27T21:16:06+00:00').timestamp()
label=sys.argv[1]; command=sys.argv[2:]
env=os.environ.copy();env.update(PYTHONPATH=str(O/'deps')+':'+str(O.parent/'model_deps'),QT_QPA_PLATFORM='offscreen',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='2',CUDA_HOME='/usr/local/cuda',CUDA_MODULE_LOADING='LAZY',PYTHONUNBUFFERED='1')
started=time.time(); records=[]
log=O/(label+'.log'); check=O/(label+'_supervision.jsonl')
if started>=deadline:raise RuntimeError('Deadline already passed')
with log.open('wb') as f:
    p=subprocess.Popen(command,cwd=O/'upstream',env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
    manifest=dict(label=label,controller_pid=os.getpid(),worker_pid=p.pid,process_group=p.pid,command=command,start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),deadline_utc='2026-10-27T21:16:06Z',memory_cap_gib=env.get('HAIRGS_MEMORY_GIB','24'),allocator_config=env.get('PYTORCH_CUDA_ALLOC_CONF'))
    (O/(label+'_controller.json')).write_text(json.dumps(manifest,indent=2))
    while True:
        now=time.time(); status=p.poll()
        def read(cmd):
            r=subprocess.run(cmd,capture_output=True,text=True,timeout=10);return r.stdout.strip() or r.stderr.strip()
        tail=log.read_bytes()[-5000:].decode(errors='replace').splitlines()
        rec=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),controller_pid=os.getpid(),worker_pid=p.pid,worker_returncode=status,
            gpu=read(['nvidia-smi','--query-gpu=memory.used,memory.total,utilization.gpu','--format=csv,noheader']),
            gpu_processes=read(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader']),
            processes=read(['ps','-o','pid,ppid,pgid,etime,rss,args','--forest','-g',str(p.pid)]),
            checkpoint_paths=[str(x.relative_to(O)) for x in O.glob('model*/point_cloud/iteration_*/point_cloud.ply')],
            oom_evidence=[x for x in tail if 'out of memory' in x.lower() or 'outofmemory' in x.lower()],tail=tail[-2:])
        with check.open('a') as out:out.write(json.dumps(rec)+'\n')
        records.append(rec)
        if status is not None:break
        if now>=deadline:
            os.killpg(p.pid,signal.SIGTERM)
            try:p.wait(timeout=20)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
            break
        try:p.wait(timeout=min(30,max(0,deadline-time.time())))
        except subprocess.TimeoutExpired:pass
manifest.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),wall_seconds=time.time()-started,returncode=p.returncode,
    log=str(log),supervision=str(check),deadline_reached=time.time()>=deadline)
(O/(label+'_receipt.json')).write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest),flush=True)
sys.exit(p.returncode or 0)
