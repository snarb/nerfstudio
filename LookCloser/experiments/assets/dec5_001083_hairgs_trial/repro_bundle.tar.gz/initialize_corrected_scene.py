import sys,json
from pathlib import Path
import numpy as np,cv2,torch
from argparse import Namespace
O=Path(__file__).resolve().parent;R=O.parent;sys.path.insert(0,str(O/'upstream'))
from scene import Scene
from gaussian_renderer import render
torch.set_num_threads(4);torch.cuda.set_per_process_memory_fraction(24*(1<<30)/torch.cuda.get_device_properties(0).total_memory)
model_path=O/'model_corrected';model_path.mkdir(exist_ok=False)
args=Namespace(source_path=str(O/'input_corrected'),model_path=str(model_path),images='images',resolution=1,sh_degree=0,data_device='cuda')
s=Scene(args,shuffle=False);s.save(0)
rows=[];background=torch.zeros(3,device='cuda')
for idx in [0,10,20,30,40,50]:
    cam=s.getCameras()[idx]
    with torch.inference_mode():pred=render(cam,s.gaussians,background)['render'].permute(1,2,0).cpu().numpy()
    assert np.isfinite(pred).all() and pred.min()>=0 and pred.max()<=1.00001
    gt=cam.original_image.permute(1,2,0).cpu().numpy()
    # Same original native raster and head window; rotation is display-only.
    panes=[np.rot90(x[0:1000,640:1480]) for x in [gt,pred]]
    panel=np.concatenate([cv2.resize(x,(500,420)) for x in panes],1)
    path=O/(cam.image_name+'_corrected_initial.jpg')
    cv2.imwrite(str(path),np.rint(panel[...,::-1]*255).astype(np.uint8))
    rows.append(dict(camera=cam.image_name,render_min=float(pred.min()),render_max=float(pred.max()),image=str(path)))
(O/'corrected_initial_render.json').write_text(json.dumps(dict(train_only=True,model_saved=str(model_path/'point_cloud/iteration_0/point_cloud.ply'),initial_points=len(s.gaussians.get_xyz),records=rows,peak_gpu_mib=torch.cuda.max_memory_allocated()/2**20),indent=2));print(json.dumps(rows),flush=True)
